package data;

import java.sql.*;
import javax.swing.JOptionPane;

public class AsistenciaDAO {

    Libreria lib = new Libreria();

    public boolean marcarEntrada(String idEmpleado) {

        String sql = "INSERT INTO Asistencia (fecha, hora_entrada_real, idTurno, idEmpleado) "
                   + "SELECT CURDATE(), CURTIME(), idTurno, ? "
                   + "FROM Empleado WHERE idEmpleado = ?";

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, idEmpleado);
            ps.setString(2, idEmpleado);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error marcar entrada: " + e.getMessage());
            return false;
        }
    }


    public boolean marcarSalida(String idEmpleado) {

        String sql = "UPDATE Asistencia "
                   + "SET hora_entrada_final = CURTIME() "
                   + "WHERE idEmpleado = ? AND fecha = CURDATE() "
                   + "AND hora_entrada_final IS NULL";

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, idEmpleado);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error marcar salida: " + e.getMessage());
            return false;
        }
    }


    public ResultSet listarAsistencia() {

        String sql = "SELECT a.idAsistencia, a.fecha, a.hora_entrada_real, a.hora_entrada_final, "
                   + "e.idEmpleado, e.Nombre, e.Apellido, t.Nombre_Turno "
                   + "FROM Asistencia a "
                   + "INNER JOIN Empleado e ON a.idEmpleado = e.idEmpleado "
                   + "INNER JOIN Turno t ON a.idTurno = t.idTurno "
                   + "ORDER BY a.fecha DESC";

        try {
            Connection cn = lib.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            return ps.executeQuery();

        } catch (SQLException e) {
            System.out.println("Error al listar asistencia: " + e.getMessage());
            return null;
        }
    }


    public boolean eliminarAsistencia(int idAsistencia) {

        String sql = "DELETE FROM Asistencia WHERE idAsistencia = ?";

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idAsistencia);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error eliminar asistencia: " + e.getMessage());
            return false;
        }
    }
}

