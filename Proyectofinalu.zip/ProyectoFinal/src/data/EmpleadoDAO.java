package data;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpleadoDAO {

    Libreria lib = new Libreria();

    public boolean existeEmpleado(String id) {

        String sql = "SELECT 1 FROM Empleado WHERE idEmpleado = ?";

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (SQLException e) {
            System.out.println("Error existeEmpleado: " + e.getMessage());
            return false;
        }
    }

    public boolean registrarEmpleado(Empleado emp) {

        String sql = "{CALL sp_insertar_empleado(?,?,?,?,?,?,?)}";

        try (Connection cn = lib.conectar();
             CallableStatement cs = cn.prepareCall(sql)) {

            cs.setString(1, emp.getIdEmpleado());
            cs.setString(2, emp.getNombre());
            cs.setString(3, emp.getApellido());
            cs.setString(4, emp.getDni());
            cs.setString(5, emp.getDireccion());
            cs.setString(6, emp.getIdDepartamento());
            cs.setString(7, emp.getIdTurno());

            return cs.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error DAO Registrar Empleado: " + e.getMessage());
            return false;
        }
    }

    public Empleado buscarEmpleado(String idEmpleado) {

        String sql = "SELECT * FROM Empleado WHERE idEmpleado = ?";
        Empleado emp = null;

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, idEmpleado);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new Empleado(
                    rs.getString("idEmpleado"),
                    rs.getString("Nombre"),
                    rs.getString("Apellido"),
                    rs.getString("Dni"),
                    rs.getString("Direccion"),
                    rs.getString("idDepartamento"),
                    rs.getString("idTurno")
                );
            }

        } catch (SQLException e) {
            System.out.println("Error buscarEmpleado: " + e.getMessage());
        }

        return emp;
    }


    public List<Empleado> listarEmpleados() {

        List<Empleado> lista = new ArrayList<>();
        String sql = "{CALL sp_listar_empleados()}";

        try (Connection cn = lib.conectar();
             CallableStatement cs = cn.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {

                Empleado emp = new Empleado(
                        rs.getString("idEmpleado"),
                        rs.getString("Nombre"),
                        rs.getString("Apellido"),
                        rs.getString("Dni"),
                        rs.getString("Direccion"),
                        rs.getString("Nombre_Departamento"),
                        rs.getString("Nombre_Turno")
                );

                lista.add(emp);
            }

        } catch (SQLException e) {
            System.out.println("Error listarEmpleados: " + e.getMessage());
        }

        return lista;
    }


 
    public boolean eliminarEmpleado(String idEmpleado) {

        String sql = "DELETE FROM Empleado WHERE idEmpleado = ?";

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, idEmpleado);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error eliminarEmpleado: " + e.getMessage());
            return false;
        }
    }
}


