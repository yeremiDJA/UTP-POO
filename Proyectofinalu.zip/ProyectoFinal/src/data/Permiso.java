package data;

public class Permiso {
    private String idPermiso;
    private String tipo_permiso;
    private String fecha_inicio;
    private String fecha_final;
    private String motivo;
    private String idEmpleado;
    
    public Permiso() {}

    public Permiso(String idPermiso, String tipo_permiso, String fecha_inicio,
                   String fecha_final, String motivo, String idEmpleado) {
    	this.idPermiso = idPermiso;
        this.tipo_permiso = tipo_permiso;
        this.fecha_inicio = fecha_inicio;
        this.fecha_final = fecha_final;
        this.motivo = motivo;
        this.idEmpleado = idEmpleado;
    }

	public String getIdPermiso() {
		return idPermiso;
	}

	public void setIdPermiso(String idPermiso) {
		this.idPermiso = idPermiso;
	}

	public String getTipo_permiso() {
		return tipo_permiso;
	}

	public void setTipo_permiso(String tipo_permiso) {
		this.tipo_permiso = tipo_permiso;
	}

	public String getFecha_inicio() {
		return fecha_inicio;
	}

	public void setFecha_inicio(String fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}

	public String getFecha_final() {
		return fecha_final;
	}

	public void setFecha_final(String fecha_final) {
		this.fecha_final = fecha_final;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getIdEmpleado() {
		return idEmpleado;
	}

	public void setIdEmpleado(String idEmpleado) {
		this.idEmpleado = idEmpleado;
	}
    
}