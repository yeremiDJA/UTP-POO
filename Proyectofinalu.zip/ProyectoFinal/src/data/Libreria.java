package data;
import java.sql.*;
public class Libreria {
	public final String driver="com.mysql.cj.jdbc.Driver";
	public final String cadena="jdbc:mysql://localhost:3306/Asistencia";
	public final String usuario="root";
	public final String clave="mysql";
	public Connection conn;
	public Connection conectar() {
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(cadena,usuario,clave);
		}catch(ClassNotFoundException e1) {
			System.out.println("Error en el driver"+e1);
		}catch(SQLException e2) {
			System.out.println("Error en el driver"+e2);
		}
		return conn;
	}
}
