package data;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class PermisoDAO {

    Libreria lib = new Libreria();

    private java.sql.Date parseToSqlDate(String input) {
        if (input == null || input.trim().isEmpty()) return null;

        DateTimeFormatter f1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter f2 = DateTimeFormatter.ISO_LOCAL_DATE;

        LocalDate ld;

        try {
            ld = LocalDate.parse(input, f1);
        } catch (DateTimeParseException e1) {
            try {
                ld = LocalDate.parse(input, f2);
            } catch (DateTimeParseException e2) {
                return null;
            }
        }

        return java.sql.Date.valueOf(ld);
    }

    private String formatToDisplay(Date d) {
        if (d == null) return "";
        LocalDate ld = d.toLocalDate();
        return ld.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    public boolean registrar(Permiso p) {

        String sql = "INSERT INTO Permiso(idPermiso, tipo_permiso, fecha_inicio, fecha_final, motivo, idEmpleado) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            java.sql.Date fInicio = parseToSqlDate(p.getFecha_inicio());
            java.sql.Date fFin    = parseToSqlDate(p.getFecha_final());

            if (fInicio == null) {
                System.out.println("Fecha Inicio inválida: " + p.getFecha_inicio());
                return false;
            }

            if (fFin == null) {
                System.out.println("Fecha Final inválida: " + p.getFecha_final());
                return false;
            }

            ps.setString(1, p.getIdPermiso());
            ps.setString(2, p.getTipo_permiso());
            ps.setDate(3, fInicio);
            ps.setDate(4, fFin);
            ps.setString(5, p.getMotivo());
            ps.setString(6, p.getIdEmpleado());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("❌ Error registrar permiso: " + e.getMessage());
            return false;
        }
    }


    public Permiso buscar(String id) {

        String sql = "SELECT * FROM Permiso WHERE idPermiso = ?";

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Permiso p = new Permiso();
                p.setIdPermiso(rs.getString("idPermiso"));
                p.setTipo_permiso(rs.getString("tipo_permiso"));
                p.setFecha_inicio(formatToDisplay(rs.getDate("fecha_inicio")));
                p.setFecha_final(formatToDisplay(rs.getDate("fecha_final")));
                p.setMotivo(rs.getString("motivo"));
                p.setIdEmpleado(rs.getString("idEmpleado"));
                return p;
            }

        } catch (SQLException e) {
            System.out.println("Error buscar permiso: " + e.getMessage());
        }

        return null;
    }

    public List<Permiso> listar() {

        List<Permiso> lista = new ArrayList<>();
        String sql = "SELECT * FROM Permiso";

        try (Connection cn = lib.conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Permiso p = new Permiso();
                p.setIdPermiso(rs.getString("idPermiso"));
                p.setTipo_permiso(rs.getString("tipo_permiso"));
                p.setFecha_inicio(formatToDisplay(rs.getDate("fecha_inicio")));
                p.setFecha_final(formatToDisplay(rs.getDate("fecha_final")));
                p.setMotivo(rs.getString("motivo"));
                p.setIdEmpleado(rs.getString("idEmpleado"));
                lista.add(p);
            }

        } catch (SQLException e) {
            System.out.println("Error listar permisos: " + e.getMessage());
        }

        return lista;
    }

        public boolean eliminar(String idPermiso) {
            String sql = "DELETE FROM Permiso WHERE idPermiso = ?";

            try (Connection cn = lib.conectar();
                 PreparedStatement ps = cn.prepareStatement(sql)) {

                ps.setString(1, idPermiso);

                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Error eliminar permiso: " + e.getMessage());
                return false;
            }
    }

}


