package controlador;

import data.EmpleadoDAO;
import data.Empleado;
import java.util.List;

public class ControlAdministrarEmpleado {

    private EmpleadoDAO dao = new EmpleadoDAO();

    public Empleado buscar(String id) {
        return dao.buscarEmpleado(id);
    }

    public boolean eliminar(String id) {
        return dao.eliminarEmpleado(id);
    }
    
    public List<Empleado> listar() {
        return dao.listarEmpleados();
    }
}