package controlador;

import data.Permiso;
import data.PermisoDAO;

import java.util.List;

public class ControladorPermiso {

    PermisoDAO dao = new PermisoDAO();

    public boolean registrar(Permiso p) {
        return dao.registrar(p);
    }

    public Permiso buscar(String id) {
        return dao.buscar(id);
    }

    public boolean eliminar(String id) {
        return dao.eliminar(id);
    }

    public List<Permiso> listar() {
        return dao.listar();
    }
}
