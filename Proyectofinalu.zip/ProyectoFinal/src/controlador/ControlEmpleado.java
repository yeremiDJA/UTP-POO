package controlador;

import data.EmpleadoDAO;
import data.Empleado;
import javax.swing.JOptionPane;

public class ControlEmpleado {

    private EmpleadoDAO empleadoDAO = new EmpleadoDAO();

    public void registrarEmpleado(String id, String nombre, String apellido,
                                  String dni, String direccion,
                                  String idDepartamento, String idTurno) {

        if (id.isEmpty() || nombre.isEmpty() || apellido.isEmpty() ||
            dni.isEmpty() || direccion.isEmpty()) {

            JOptionPane.showMessageDialog(null, 
                "Todos los campos son obligatorios");
            return;
        }

        if (!dni.matches("\\d{8}")) {
            JOptionPane.showMessageDialog(null, 
                "El DNI debe contener exactamente 8 números");
            return;
        }

        if (empleadoDAO.existeEmpleado(id)) {
            JOptionPane.showMessageDialog(null, 
                "El ID del empleado ya existe");
            return;
        }

        Empleado emp = new Empleado(id, nombre, apellido, dni, direccion,
                                   idDepartamento, idTurno);

        boolean ok = empleadoDAO.registrarEmpleado(emp);

        if (ok) {
            JOptionPane.showMessageDialog(null, 
                "Empleado registrado exitosamente");
        } else {
            JOptionPane.showMessageDialog(null, 
                "Error al registrar empleado");
        }
    }
    public Empleado buscarEmpleado(String id) {
        return empleadoDAO.buscarEmpleado(id);
    }
}

