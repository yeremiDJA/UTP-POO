package controlador;

import data.AsistenciaDAO;
import java.sql.ResultSet;

public class ControlAsistencia {

    AsistenciaDAO dao = new AsistenciaDAO();

    public boolean marcarEntrada(String idEmpleado) {
        return dao.marcarEntrada(idEmpleado);
    }

    public boolean marcarSalida(String idEmpleado) {
        return dao.marcarSalida(idEmpleado);
    }

    public ResultSet listarAsistencia() {
        return dao.listarAsistencia();
    }

    public boolean eliminarAsistencia(int id) {
        return dao.eliminarAsistencia(id);
    }
}
