package view;

import controlador.ControlEmpleado;
import data.Libreria;
import java.sql.*;
import javax.swing.*;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;

public class Vista extends javax.swing.JFrame {

    ControlEmpleado control = new ControlEmpleado();
    Libreria lib = new Libreria();

    JButton btnRegresar;

    public Vista() {
        initComponents();
        cargarDepartamentos();
        cargarTurnos();
    }

    private void initComponents() {

        setTitle("Registro de Empleados");
        setSize(500, 500);
        getContentPane().setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel lblId = new JLabel("ID Empleado:");
        lblId.setBounds(30, 30, 100, 25);
        getContentPane().add(lblId);

        txtId = new JTextField();
        txtId.setBounds(150, 30, 200, 25);
        getContentPane().add(txtId);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 70, 100, 25);
        getContentPane().add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(150, 70, 200, 25);
        getContentPane().add(txtNombre);

        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setBounds(30, 110, 100, 25);
        getContentPane().add(lblApellido);

        txtApellido = new JTextField();
        txtApellido.setBounds(150, 110, 200, 25);
        getContentPane().add(txtApellido);

        JLabel lblDni = new JLabel("DNI:");
        lblDni.setBounds(30, 150, 100, 25);
        getContentPane().add(lblDni);

        txtDni = new JTextField();
        txtDni.setBounds(150, 150, 200, 25);
        getContentPane().add(txtDni);

        JLabel lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(30, 190, 100, 25);
        getContentPane().add(lblDireccion);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(150, 190, 200, 25);
        getContentPane().add(txtDireccion);

        JLabel lblDep = new JLabel("Departamento:");
        lblDep.setBounds(30, 230, 100, 25);
        getContentPane().add(lblDep);

        cboDepartamento = new JComboBox<>();
        cboDepartamento.setBounds(150, 230, 200, 25);
        getContentPane().add(cboDepartamento);

        JLabel lblTurno = new JLabel("Turno:");
        lblTurno.setBounds(30, 270, 100, 25);
        getContentPane().add(lblTurno);

        cboTurno = new JComboBox<>();
        cboTurno.setBounds(150, 270, 200, 25);
        getContentPane().add(cboTurno);

        JButton btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(150, 330, 120, 35);
        getContentPane().add(btnRegistrar);

        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(290, 330, 120, 35);
        getContentPane().add(btnRegresar);

        btnRegistrar.addActionListener(e -> registrarEmpleado());
        btnRegresar.addActionListener(e -> regresar());

        getContentPane().setFocusTraversalPolicy(
                new FocusTraversalOnArray(
                        new Component[]{txtId, txtNombre, cboDepartamento, lblId, txtApellido, lblNombre, lblDni, lblApellido, lblDireccion, txtDni, txtDireccion, lblDep, lblTurno, cboTurno, btnRegistrar}
                ));
    }

    public void cargarDepartamentos() {
        try {
            Connection cn = lib.conectar();
            PreparedStatement pst = cn.prepareStatement("CALL sp_listar_departamentos()");
            ResultSet rs = pst.executeQuery();

            cboDepartamento.removeAllItems();
            cboDepartamento.addItem("Seleccionar");

            while(rs.next()) {
                cboDepartamento.addItem(rs.getString("idDepartamento") + " - " + rs.getString("Nombre_Departamento"));
            }
            cn.close();
        } catch (Exception e) {
            System.out.println("Error al cargar departamentos: " + e);
            e.printStackTrace();
        }
    }

    public void cargarTurnos() {
        try {
            Connection cn = lib.conectar();
            PreparedStatement pst = cn.prepareStatement("CALL sp_listar_turnos()");
            ResultSet rs = pst.executeQuery();

            cboTurno.removeAllItems();
            cboTurno.addItem("Seleccionar");

            while(rs.next()) {
                cboTurno.addItem(rs.getString("idTurno") + " - " + rs.getString("Nombre_Turno"));
            }
            cn.close();
        } catch (Exception e) {
            System.out.println("Error al cargar turnos: " + e);
        }
    }

    private void registrarEmpleado() {

        String id = txtId.getText();
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String dni = txtDni.getText();
        String direccion = txtDireccion.getText();

        String dep = cboDepartamento.getSelectedItem().toString();
        String idDep = dep.split(" - ")[0];

        String turn = cboTurno.getSelectedItem().toString();
        String idTurn = turn.split(" - ")[0];

        control.registrarEmpleado(id, nombre, apellido, dni, direccion, idDep, idTurn);
    }

    private void regresar() {
        new PantallaPrincipal().setVisible(true); 
        dispose();
    }

    JTextField txtId, txtNombre, txtApellido, txtDni, txtDireccion;
    JComboBox<String> cboDepartamento, cboTurno;
}


