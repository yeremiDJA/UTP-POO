package view;

import controlador.ControlAdministrarEmpleado;
import data.Empleado;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class Vista3 extends JFrame {

    private ControlAdministrarEmpleado control = new ControlAdministrarEmpleado();

    private JTextField txtId, txtNombre, txtApellido, txtDni, txtDireccion;
    private JTable tabla;
    private DefaultTableModel modelo;

    public Vista3() {
        initComponents();
    }

    private void initComponents() {

        setTitle("Administrar Empleados");
        setSize(650, 500);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(20, 20, 80, 25);
        add(lblId);

        txtId = new JTextField();
        txtId.setBounds(100, 20, 120, 25);
        add(txtId);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(240, 20, 100, 25);
        add(btnBuscar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(360, 20, 100, 25);
        add(btnEliminar);

        JButton btnListar = new JButton("Listar");
        btnListar.setBounds(480, 20, 100, 25);
        add(btnListar);

        JButton btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(20, 420, 120, 30);
        add(btnRegresar);

        txtNombre = new JTextField();
        txtApellido = new JTextField();
        txtDni = new JTextField();
        txtDireccion = new JTextField();

        int y = 70;
        addLabel("Nombre:", 20, y); addField(txtNombre, 120, y); y += 40;
        addLabel("Apellido:", 20, y); addField(txtApellido, 120, y); y += 40;
        addLabel("DNI:", 20, y); addField(txtDni, 120, y); y += 40;
        addLabel("Dirección:", 20, y); addField(txtDireccion, 120, y);

        modelo = new DefaultTableModel(new String[]{"ID", "Nombre", "Apellido", "DNI", "Dirección", "Dept.", "Turno"}, 0);
        tabla = new JTable(modelo);

        JScrollPane sp = new JScrollPane(tabla);
        sp.setBounds(20, 250, 600, 150);
        add(sp);

        btnBuscar.addActionListener(e -> buscar());
        btnEliminar.addActionListener(e -> eliminar());
        btnListar.addActionListener(e -> listar());
        btnRegresar.addActionListener(e -> {
            PantallaPrincipal menu = new PantallaPrincipal();
            menu.setVisible(true);
            dispose();
        });

    }

    private void addLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 100, 25);
        add(lbl);
    }

    private void addField(JTextField txt, int x, int y) {
        txt.setBounds(x, y, 200, 25);
        txt.setEditable(false);
        add(txt);
    }

    private void buscar() {
        String id = txtId.getText().trim();

        Empleado emp = control.buscar(id);

        if (emp == null) {
            JOptionPane.showMessageDialog(this, "Empleado no encontrado");
            limpiarCampos();
            return;
        }

        txtNombre.setText(emp.getNombre());
        txtApellido.setText(emp.getApellido());
        txtDni.setText(emp.getDni());
        txtDireccion.setText(emp.getDireccion());
    }

    private void eliminar() {
        String id = txtId.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID");
            return;
        }

        if (control.eliminar(id)) {
            JOptionPane.showMessageDialog(this, "Empleado eliminado correctamente");
            limpiarCampos();
            listar();
        } else {
            JOptionPane.showMessageDialog(this, "Error al eliminar empleado");
        }
    }

    private void listar() {
        modelo.setRowCount(0);

        List<Empleado> lista = control.listar();

        for (Empleado emp : lista) {
            modelo.addRow(new Object[]{
                    emp.getIdEmpleado(),
                    emp.getNombre(),
                    emp.getApellido(),
                    emp.getDni(),
                    emp.getDireccion(),
                    emp.getIdDepartamento(),
                    emp.getIdTurno()
            });
        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        txtDireccion.setText("");
    }
}

