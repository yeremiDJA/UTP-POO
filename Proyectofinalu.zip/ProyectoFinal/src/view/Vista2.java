package view;

import controlador.ControlAsistencia;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Vista2 extends JFrame {

    private ControlAsistencia control = new ControlAsistencia();

    private JTable tabla;
    private DefaultTableModel modelo;

    private JTextField txtIDEmpleado, txtBuscar;
    private JButton btnEntrada, btnSalida, btnListar, btnEliminar, btnRegresar;

    public Vista2() {
        initComponents();
        listarAsistencia();
    }

    private void initComponents() {

        setTitle("Gestión Completa de Asistencia");
        setSize(950, 600);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ====== REGISTRAR ENTRADA Y SALIDA ======
        JLabel lblID = new JLabel("ID Empleado:");
        lblID.setBounds(20, 20, 100, 25);
        add(lblID);

        txtIDEmpleado = new JTextField();
        txtIDEmpleado.setBounds(120, 20, 120, 25);
        add(txtIDEmpleado);

        btnEntrada = new JButton("Registrar Entrada");
        btnEntrada.setBounds(260, 20, 150, 25);
        add(btnEntrada);

        btnSalida = new JButton("Registrar Salida");
        btnSalida.setBounds(420, 20, 150, 25);
        add(btnSalida);

        // ===== BUSCAR Y ELIMINAR =====
        JLabel lblBuscar = new JLabel("ID Asistencia:");
        lblBuscar.setBounds(20, 60, 100, 25);
        add(lblBuscar);

        txtBuscar = new JTextField();
        txtBuscar.setBounds(120, 60, 120, 25);
        add(txtBuscar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(260, 60, 150, 25);
        add(btnEliminar);

        btnListar = new JButton("Listar Todo");
        btnListar.setBounds(420, 60, 150, 25);
        add(btnListar);

        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(580, 20, 150, 25);
        add(btnRegresar);

        // ======= TABLA =========
        modelo = new DefaultTableModel(
                new String[]{
                        "ID", "Fecha", "Entrada Real", "Salida Real",
                        "ID Empleado", "Nombre", "Apellido", "Turno"
                }, 0
        );

        tabla = new JTable(modelo);
        JScrollPane sp = new JScrollPane(tabla);
        sp.setBounds(20, 110, 900, 420);
        add(sp);

        // Eventos
        btnEntrada.addActionListener(e -> registrarEntrada());
        btnSalida.addActionListener(e -> registrarSalida());
        btnEliminar.addActionListener(e -> eliminarAsistencia());
        btnListar.addActionListener(e -> listarAsistencia());
        btnRegresar.addActionListener(e -> regresar());
    }



    private void registrarEntrada() {
        String idEmp = txtIDEmpleado.getText().trim();

        if (idEmp.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese ID de empleado.");
            return;
        }

        if (control.marcarEntrada(idEmp)) {
            JOptionPane.showMessageDialog(this, "Entrada registrada.");
            listarAsistencia();
            txtIDEmpleado.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar entrada.");
        }
    }

    private void registrarSalida() {
        String idEmp = txtIDEmpleado.getText().trim();

        if (idEmp.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese ID de empleado.");
            return;
        }

        if (control.marcarSalida(idEmp)) {
            JOptionPane.showMessageDialog(this, "Salida registrada.");
            listarAsistencia();
            txtIDEmpleado.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar salida.");
        }
    }

    private void listarAsistencia() {
        modelo.setRowCount(0);

        ResultSet rs = control.listarAsistencia();

        try {
            while (rs != null && rs.next()) {
                modelo.addRow(new Object[]{
                        rs.getInt("idAsistencia"),
                        rs.getString("fecha"),
                        rs.getString("hora_entrada_real"),
                        rs.getString("hora_entrada_final"),
                        rs.getString("idEmpleado"),
                        rs.getString("Nombre"),
                        rs.getString("Apellido"),
                        rs.getString("Nombre_Turno")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error al listar asistencia: " + e.getMessage());
        }
    }

    private void eliminarAsistencia() {
        String txt = txtBuscar.getText().trim();

        if (txt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID para eliminar.");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(txt);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID inválido.");
            return;
        }

        if (control.eliminarAsistencia(id)) {
            JOptionPane.showMessageDialog(this, "Asistencia eliminada.");
            listarAsistencia();
            txtBuscar.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar.");
        }
    }

    private void regresar() {
        new PantallaPrincipal().setVisible(true);
        dispose();
    }
}


