package view;
import view.Vista;
public class MainPrincipal {
	public static void main(String[] args) {
		new view.PantallaPrincipal().setVisible(true);
	}
}
