package view;

import javax.swing.*;

public class PantallaPrincipal extends JFrame {

    JButton btnRegistrar, btnAsistencia, btnAdministrador, btnPermisos, btnSalir;

    public PantallaPrincipal() {
        initComponents();
    }

    private void initComponents() {

        setTitle("Menú Principal");
        setSize(350, 380);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnRegistrar = new JButton("Registrar Empleado");
        btnRegistrar.setBounds(80, 30, 180, 35);
        add(btnRegistrar);

        btnAsistencia = new JButton("Marcar Asistencia");
        btnAsistencia.setBounds(80, 80, 180, 35);
        add(btnAsistencia);

        btnAdministrador = new JButton("Administrar Empleados");
        btnAdministrador.setBounds(80, 130, 180, 35);
        add(btnAdministrador);

        btnPermisos = new JButton("Administrar Permisos");
        btnPermisos.setBounds(80, 180, 180, 35);
        add(btnPermisos);

        btnSalir = new JButton("Salir");
        btnSalir.setBounds(80, 230, 180, 35);
        add(btnSalir);

        btnRegistrar.addActionListener(e -> abrirRegistro());
        btnAsistencia.addActionListener(e -> abrirAsistencia());
        btnAdministrador.addActionListener(e -> abrirAdministrador());
        btnPermisos.addActionListener(e -> abrirPermisos());
        btnSalir.addActionListener(e -> System.exit(0));
    }

    private void abrirRegistro() {
        Vista registro = new Vista();
        registro.setVisible(true);
    }

    private void abrirAsistencia() {
        Vista2 asistencia = new Vista2();
        asistencia.setVisible(true);
    }

    private void abrirAdministrador() {
        Vista3 admin = new Vista3();
        admin.setVisible(true);
    }

    private void abrirPermisos() {
        Vista4 permiso = new Vista4();
        permiso.setVisible(true);
    }
}

