package view;

import controlador.ControladorPermiso;
import data.Permiso;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class Vista4 extends JFrame {

    private JTextField txtId, txtTipo, txtFechaInicio, txtFechaFin, txtMotivo, txtEmpleado;
    private JTable tabla;
    private DefaultTableModel modelo;
    private ControladorPermiso control = new ControladorPermiso();

    public Vista4() {
        initComponents();
    }

    private void initComponents() {

        setTitle("Permisos");
        setSize(700, 500);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lbl1 = new JLabel("ID Permiso:");
        lbl1.setBounds(20, 20, 120, 25);
        add(lbl1);

        txtId = new JTextField();
        txtId.setBounds(140, 20, 150, 25);
        add(txtId);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(320, 20, 100, 25);
        add(btnBuscar);

        JLabel lbl2 = new JLabel("Tipo Permiso:");
        lbl2.setBounds(20, 60, 120, 25);
        add(lbl2);

        txtTipo = new JTextField();
        txtTipo.setBounds(140, 60, 150, 25);
        add(txtTipo);

        JLabel lbl3 = new JLabel("Fecha Inicio:");
        lbl3.setBounds(20, 100, 120, 25);
        add(lbl3);

        txtFechaInicio = new JTextField();
        txtFechaInicio.setBounds(140, 100, 150, 25);
        add(txtFechaInicio);

        JLabel lbl4 = new JLabel("Fecha Final:");
        lbl4.setBounds(20, 140, 120, 25);
        add(lbl4);

        txtFechaFin = new JTextField();
        txtFechaFin.setBounds(140, 140, 150, 25);
        add(txtFechaFin);

        JLabel lbl5 = new JLabel("Motivo:");
        lbl5.setBounds(20, 180, 120, 25);
        add(lbl5);

        txtMotivo = new JTextField();
        txtMotivo.setBounds(140, 180, 150, 25);
        add(txtMotivo);

        JLabel lbl6 = new JLabel("ID Empleado:");
        lbl6.setBounds(20, 220, 120, 25);
        add(lbl6);

        txtEmpleado = new JTextField();
        txtEmpleado.setBounds(140, 220, 150, 25);
        add(txtEmpleado);

        JButton btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(320, 60, 100, 30);
        add(btnRegistrar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(320, 100, 100, 30);
        add(btnEliminar);

        JButton btnListar = new JButton("Listar");
        btnListar.setBounds(320, 140, 100, 30);
        add(btnListar);

        JButton btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(20, 420, 120, 30);
        add(btnRegresar);

        modelo = new DefaultTableModel(new String[]{
                "ID Permiso", "Tipo", "Inicio", "Fin", "Motivo", "Empleado"
        }, 0);
        tabla = new JTable(modelo);

        JScrollPane sp = new JScrollPane(tabla);
        sp.setBounds(20, 270, 640, 130);
        add(sp);

        btnRegistrar.addActionListener(e -> registrar());
        btnBuscar.addActionListener(e -> buscar());
        btnEliminar.addActionListener(e -> eliminar());
        btnListar.addActionListener(e -> listar());
        btnRegresar.addActionListener(e -> dispose());
    }

    private void registrar() {
        Permiso p = new Permiso(
                txtId.getText(),
                txtTipo.getText(),
                txtFechaInicio.getText(),
                txtFechaFin.getText(),
                txtMotivo.getText(),
                txtEmpleado.getText()
        );

        if (control.registrar(p)) {
            JOptionPane.showMessageDialog(this, "Permiso registrado");
            listar();
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar");
        }
    }

    private void buscar() {
        Permiso p = control.buscar(txtId.getText());
        if (p == null) {
            JOptionPane.showMessageDialog(this, "No encontrado");
            return;
        }

        txtTipo.setText(p.getTipo_permiso());
        txtFechaInicio.setText(p.getFecha_inicio());
        txtFechaFin.setText(p.getFecha_final());
        txtMotivo.setText(p.getMotivo());
        txtEmpleado.setText(p.getIdEmpleado());
    }

    private void eliminar() {
        if (control.eliminar(txtId.getText())) {
            JOptionPane.showMessageDialog(this, "Permiso eliminado");
            listar();
        } else {
            JOptionPane.showMessageDialog(this, "Error al eliminar");
        }
    }

    private void listar() {
        modelo.setRowCount(0);

        List<Permiso> lista = control.listar();

        for (Permiso p : lista) {
            modelo.addRow(new Object[]{
                    p.getIdPermiso(),
                    p.getTipo_permiso(),
                    p.getFecha_inicio(),
                    p.getFecha_final(),
                    p.getMotivo(),
                    p.getIdEmpleado()
            });
        }
    }
}


